1) What the app does?

	I have created a to-do list app. Using this app you can
	create tasks that needs to be done. Later after completion
	of the task you can delete them. The data about the tasks 
	is stored in a local SQLite database on the user's phone.

2) There are no deployment or emulator restrictions

3) References:

	a) https://www.youtube.com/watch?v=RXtj4TxMmW0

	b) www.google.com